package com.mini.service;

public interface MypageService {

}
