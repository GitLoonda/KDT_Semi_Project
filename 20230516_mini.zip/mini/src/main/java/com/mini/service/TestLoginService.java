package com.mini.service;

import java.util.HashMap;

public interface TestLoginService {
	
	// 로그인
	HashMap<String, Object> test123(HashMap<String, Object> map) throws Exception;

}
