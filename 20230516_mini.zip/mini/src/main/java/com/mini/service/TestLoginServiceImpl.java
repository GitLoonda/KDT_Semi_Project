package com.mini.service;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mini.mapper.TestLoginMapper;
import com.mini.model.TestUser;

@Service
public class TestLoginServiceImpl implements TestLoginService {
	
	@Autowired
	private TestLoginMapper testLoginMapper;

	@Override
	public HashMap<String, Object> test123(HashMap<String, Object> map) throws Exception {
		// TODO Auto-generated method stub
		
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
{
			TestUser user = testLoginMapper.test123(map);
			if(user != null) {
				resultMap.put("user", user);
				resultMap.put("result", "success");
				resultMap.put("message", user.getId() + "님 환영합니다.");
			} else {
				 resultMap.put("result", "fail");
				 resultMap.put("message", "아이디와 패스워드를 다시 확인해주세요.");
				 
			}
			
		return resultMap;
	}
	}

}
