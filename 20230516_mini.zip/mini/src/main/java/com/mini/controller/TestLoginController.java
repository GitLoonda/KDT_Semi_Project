package com.mini.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.mini.model.TestUser;
import com.mini.service.TestLoginService;

import jakarta.servlet.http.HttpSession;

@Controller
public class TestLoginController {
	
	@Autowired
	private TestLoginService testloginService;
	
	@Autowired
	HttpSession session;	// 세션 만들기 ( 아이디 권한 만들기 )
	


	@RequestMapping("/testlogin.do") 	// 주소 이름 만들기
    public String login(Model model) throws Exception{

        return "/test-login";		//실행 시킬 파일
    }

	
	@RequestMapping(value = "/testlogin.dox", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	@ResponseBody
	public String test123(Model model, @RequestParam HashMap<String, Object> map) throws Exception {
		
		HashMap<String, Object> resultMap = new HashMap<String, Object>();
		resultMap = testloginService.test123(map);
		String result = (String) resultMap.get("result");
		/*
		 * if(result.equals("success")) { TestUser user = (TestUser)
		 * resultMap.get("user"); session.setAttribute("sessionId", user.getId());
		 * 
		 * }
		 */
		return new Gson().toJson(resultMap);
	}
	
	
}