package com.mini.model;

import lombok.Data;

public class TbrdList {
    private int tbno;
    private String id;
    private String nick;
    private String phone;
    private String email;
    private int bprice;
    private String btitle;
    private String bcont;
    private int hits;
    private int likes;
    private int grade;
    private String brdname;
    private String kindname;
    private String cate1name;
    private String cate2name;
    private String cate3name;
    private String bprodname;
    private String bprosname;
    private String bstatusname;
    private String bpurname;
    private String bboxname;
    private String brcptname;
    private String bcmsname;
    private String local1name;
    private String local2name;
    private String local3name;
    private String cdate;
    private String udate;
    private String delYn;
    private int tbrdcnt;
    private String path;



}
