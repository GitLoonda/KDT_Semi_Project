package com.mini.model;
import lombok.Data;
public class Area {
    private int idx;
    private String si;
    private String gu;
    private String dong;
}
