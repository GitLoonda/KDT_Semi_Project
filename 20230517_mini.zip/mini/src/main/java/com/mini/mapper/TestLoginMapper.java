package com.mini.mapper;

import java.util.HashMap;

import org.apache.ibatis.annotations.Mapper;

import com.mini.model.TestUser;


@Mapper		
public interface TestLoginMapper {
	
	// 로그인
	TestUser test123(HashMap<String, Object> map) throws Exception; 
	
}
