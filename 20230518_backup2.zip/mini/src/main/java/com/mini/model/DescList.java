package com.mini.model;

import lombok.Data;

public class DescList {
    private int dno;
    private String cid;
    private String cnum;
    private String cinfo;
    private String pcomm1;
    private String pcomm2;

}
