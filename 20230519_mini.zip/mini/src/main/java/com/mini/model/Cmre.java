package com.mini.model;

import lombok.Data;

public class Cmre {
	private int cbno;
	private String cdate;
	private int cno;
	private String conte;
	private String delYn;
	private String id;
	private int recno;
	private String reconte;
	private String revwflg;
	private String showYn;
	private int tbno;
	private String udate;
	
	
	
	public int getCbno() {
		return cbno;
	}
	public void setCbno(int cbno) {
		this.cbno = cbno;
	}
	public String getCdate() {
		return cdate;
	}
	public void setCdate(String cdate) {
		this.cdate = cdate;
	}
	public int getCno() {
		return cno;
	}
	public void setCno(int cno) {
		this.cno = cno;
	}
	public String getConte() {
		return conte;
	}
	public void setConte(String conte) {
		this.conte = conte;
	}
	public String getDelYn() {
		return delYn;
	}
	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public int getRecno() {
		return recno;
	}
	public void setRecno(int recno) {
		this.recno = recno;
	}
	public String getReconte() {
		return reconte;
	}
	public void setReconte(String reconte) {
		this.reconte = reconte;
	}
	public String getRevwflg() {
		return revwflg;
	}
	public void setRevwflg(String revwflg) {
		this.revwflg = revwflg;
	}
	public String getShowYn() {
		return showYn;
	}
	public void setShowYn(String showYn) {
		this.showYn = showYn;
	}
	public int getTbno() {
		return tbno;
	}
	public void setTbno(int tbno) {
		this.tbno = tbno;
	}
	public String getUdate() {
		return udate;
	}
	public void setUdate(String udate) {
		this.udate = udate;
	}
	

	
	
}
