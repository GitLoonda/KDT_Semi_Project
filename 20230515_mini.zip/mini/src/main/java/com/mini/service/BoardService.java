package com.mini.service;

public interface BoardService {

}
